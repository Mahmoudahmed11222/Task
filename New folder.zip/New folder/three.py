# tm_divisible_by_3.py

class TuringMachine:
    def __init__(self, states, input_alphabet, tape_alphabet, transitions,
                 start_state, accept_state, reject_state, blank_symbol='⊔'):
        self.states = set(states)
        self.input_alphabet = set(input_alphabet)
        self.tape_alphabet = set(tape_alphabet)
        self.transitions = transitions  # قاموس للانتقالات
        self.start_state = start_state
        self.accept_state = accept_state
        self.reject_state = reject_state
        self.blank_symbol = blank_symbol

        # التحقق من أن كل الحالات المستخدمة في الانتقالات معرفة
        for state_from, rules in self.transitions.items():
            if state_from not in self.states:
                raise ValueError(f"State '{state_from}' in transitions is not in defined states.")
            for symbol_read, (state_to, _, _) in rules.items():
                if state_to not in self.states:
                    raise ValueError(f"State '{state_to}' in transition from '{state_from}' "
                                     f"on '{symbol_read}' is not in defined states.")

    def _initialize_tape(self, input_string):
        """يهيئ الشريط بالإدخال."""
        tape = {}
        for i, char in enumerate(input_string):
            if char not in self.input_alphabet:
                # إذا أردنا السماح برموز ليست في أبجدية الإدخال على الشريط (مثل الرموز المساعدة)
                # يجب تعديل هذا الشرط. حاليًا، نفترض أن الإدخال فقط من أبجدية الإدخال.
                # ولكن آلة تورينج يمكن أن تكتب رموزًا من tape_alphabet.
                # For input, it must be from input_alphabet.
                raise ValueError(f"Input symbol '{char}' not in input alphabet.")
            tape[i] = char
        return tape

    def simulate(self, input_string, max_steps=1000):
        """
        يحاكي عمل آلة تورينج على سلسلة مدخلة.
        ترجع True إذا تم القبول، False إذا تم الرفض أو تجاوز الحد الأقصى للخطوات.
        """
        if not all(c in self.input_alphabet for c in input_string):
             print(f"Error: Input string '{input_string}' contains symbols not in the input alphabet.")
             return False # أو تثير خطأ

        tape = self._initialize_tape(input_string)
        current_state = self.start_state
        head_position = 0
        steps = 0

        # طباعة الحالة الأولية (اختياري للتتبع)
        # print(f"Step {steps}: Tape: {dict(sorted(tape.items()))}, Head: {head_position}, State: {current_state}")

        while steps < max_steps:
            if current_state == self.accept_state:
                print(f"Accepted '{input_string}' in {steps} steps.")
                return True
            if current_state == self.reject_state:
                print(f"Rejected '{input_string}' in {steps} steps.")
                return False

            # قراءة الرمز الحالي تحت الرأس
            current_symbol_on_tape = tape.get(head_position, self.blank_symbol)

            # البحث عن انتقال
            if current_state not in self.transitions or \
               current_symbol_on_tape not in self.transitions[current_state]:
                # لا يوجد انتقال محدد -> رفض (أو حسب تعريف الآلة)
                print(f"No transition defined for state '{current_state}' and symbol '{current_symbol_on_tape}'. Rejecting.")
                return False

            # الحصول على الانتقال
            new_state, symbol_to_write, direction = self.transitions[current_state][current_symbol_on_tape]

            # تنفيذ الانتقال
            tape[head_position] = symbol_to_write    # كتابة الرمز
            current_state = new_state                 # تغيير الحالة

            # تحريك الرأس
            if direction == 'R':
                head_position += 1
            elif direction == 'L':
                head_position -= 1
            elif direction == 'S':
                pass  # لا تتحرك
            else:
                raise ValueError(f"Invalid direction '{direction}' in transition.")

            steps += 1
            # طباعة كل خطوة (اختياري للتتبع)
            # print(f"Step {steps}: Tape: {dict(sorted(tape.items()))}, Head: {head_position}, State: {current_state}, Wrote: {symbol_to_write}, Moved: {direction}")


        print(f"Exceeded maximum steps ({max_steps}) for input '{input_string}'. Assuming rejection.")
        return False

# --- نهاية كلاس TuringMachine ---


# =============================================
# تعريف آلة تورينج للأعداد الثنائية القابلة للقسمة على 3
# =============================================
def create_divisible_by_3_tm():
    states = {'q_rem0', 'q_rem1', 'q_rem2', 'q_accept', 'q_reject'}
    input_alphabet = {'0', '1'}
    tape_alphabet = {'0', '1', '⊔'} # ⊔ هو رمز الفراغ
    blank_symbol = '⊔'
    start_state = 'q_rem0' # نبدأ بباقي 0
    accept_state = 'q_accept'
    reject_state = 'q_reject'

    transitions = {
        'q_rem0': {
            '0': ('q_rem0', '0', 'R'),  # (0*2+0)%3 = 0
            '1': ('q_rem1', '1', 'R'),  # (0*2+1)%3 = 1
            blank_symbol: ('q_accept', blank_symbol, 'S') # نهاية العدد، الباقي 0 -> قبول
        },
        'q_rem1': {
            '0': ('q_rem2', '0', 'R'),  # (1*2+0)%3 = 2
            '1': ('q_rem0', '1', 'R'),  # (1*2+1)%3 = 0
            blank_symbol: ('q_reject', blank_symbol, 'S') # نهاية العدد، الباقي 1 -> رفض
        },
        'q_rem2': {
            '0': ('q_rem1', '0', 'R'),  # (2*2+0)%3 = 1
            '1': ('q_rem2', '1', 'R'),  # (2*2+1)%3 = 2
            blank_symbol: ('q_reject', blank_symbol, 'S') # نهاية العدد، الباقي 2 -> رفض
        }
        # لا نحتاج لتعريف انتقالات من q_accept أو q_reject لأن الآلة تتوقف عندهما
    }

    tm = TuringMachine(states, input_alphabet, tape_alphabet, transitions,
                       start_state, accept_state, reject_state, blank_symbol)
    return tm

# --- نهاية دالة create_divisible_by_3_tm ---


# =============================================
# كتلة التنفيذ الرئيسية للاختبار
# =============================================
if __name__ == "__main__":
    # إنشاء آلة تورينج المحددة
    tm_div3 = create_divisible_by_3_tm()

    test_strings = [
        "",       # 0 (decimal) -> Accept (بناءً على انتقال q_rem0 من الفراغ)
        "0",      # 0 (decimal) -> Accept
        "1",      # 1 (decimal) -> Reject
        "10",     # 2 (decimal) -> Reject
        "11",     # 3 (decimal) -> Accept
        "100",    # 4 (decimal) -> Reject
        "101",    # 5 (decimal) -> Reject
        "110",    # 6 (decimal) -> Accept
        "111",    # 7 (decimal) -> Reject
        "1000",   # 8 (decimal) -> Reject
        "1001",   # 9 (decimal) -> Accept
        "0000",   # 0 (decimal) -> Accept
        "0011"    # 3 (decimal) -> Accept
    ]

    print("--- Testing Turing Machine for Divisibility by 3 ---")
    for s in test_strings:
        print(f"\nInput: '{s}'")
        result = tm_div3.simulate(s)
        expected = "Accept" if (s == "" or int(s, 2) % 3 == 0) else "Reject"
        print(f"Result: {'Accept' if result else 'Reject'} (Expected: {expected})")
        if ('Accept' if result else 'Reject') != expected:
             print(f"****** MISMATCH for input '{s}' ******")
    print("----------------------------------------------------")